/*
 *Date started: 4/6/2019 
 *Last updated: 4/12/18
 *
 * Programmer: Doncheski Francis
 *
 * Program:    Account Class
 *
 * Purpouse :  Used to manipulate account information.
 *
 */
package doncheski;

import java.util.Scanner;
public class Account
{// start of Account class 

              Scanner inpA = new Scanner(System.in);
            //instance variable 
           final private String name;
            private String pin;
            private double balance;
            private int accountId; 
            private boolean check = false;
            //class variable 
     static private int accountIdIncrement = 101;
     
     //constructor n is the name, PI is the pin/password, bA is the balance
     public Account(String n,String pI, int bA)
   {
       name = n;
       balance = bA;
       pin = pI;
     accountId = accountIdIncrement++;
   
   }
     // get name method 
   public String getName()
    {
        return name;
    }
   // Will allow you to change the name if needed/ not yet implemented
   // im also not sure why you requested all instance variables 
   // to have a get & set?
   public void setName(String numb)
           {
               
           }
   
     // get password method 
     public String getPassword()
    {
        return pin;
    }
    // Will allow you to change the password/ not yet implemented.
     public void setPassword(String numb)
           {
               
           }
     
     // get balance method 
      public double getBalance()
    {
        return balance;
    }
      // Will allow you to change the balance/ not yet implemented.
      // I may make this a manager feature if on the off chance there
      // was an error made by the clerk.
       public void setBalance(double numb)
           {
               balance = numb;
           }
      
     // get accountId method 
    public int getAccountId()
    {
        return accountId;
    }
    // Im not sure why you would ever need to change this since
    // it is automaticly generated?
     public void setAccountId(String numb)
           {
               
           }
     
}// end of Account class