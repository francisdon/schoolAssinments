/*
 * Project: Random Numbers Game
 * 
 * Name: Francis Doncheski
 * 
 * Date Started: 3/4/19
 * Last Modified:3/10/19
 *
 * Purpose: Try to guess the number the computer generates between 1-100
 */
package doncheski;

import java.util.Random;
import java.util.Scanner;

// RandomNumberGame class start
public class RandomNumberGame 
{ 
// Main method start
 public static void main(String[] args) 
 { 

  // Objects
  Random rnd = new Random();
  Scanner sc = new Scanner(System.in);
  
  // Variables 
  // Variables used only in RandomNumberGame
  // limit to the amount of guesses you can make
  final byte limit = 10;
  // The amount of guesses you have made
  byte guessNumber = 0;
  // Holds the random number
  byte computerNumber = 0;
  // Used to see if you went over the amount of attempts
  byte attempts = 0;
  // The number the user enters
  byte userNumber = 0;
  // Used for score
  boolean check = false;
  // Variables used only in cup game
  // red, yellow, blue, All hold the values for the Cup Game
  byte red = 0;
  byte blue = 0;
  byte yellow = 0;
  // used for score
  int minMax = 0;
  boolean decider;
  boolean difficulty;
  String small = "smallest vlaue";
  String large = "largest value";
  // Variables used in more then one case.
  // Used for Random Number Game score
  byte score = 0;
  // Holds the value for the game you just played
  byte previous = 0;
  // used for cup game score
  byte cScore = 0;
  byte cCheck = 0;
  // Used to restart the game
  String ply = "";
  // Used to restart the menu
  String menuChoice = "";
  // Used to get the users name
  String userName = "";
  // Used to select an option
  String option = "";
  // Asks for user name, added for user friendliness.
  System.out.println("Please enter your name?");
  userName = sc.nextLine();

  do // do while loop start of do #1
  {
   // This is my home screen used to choose what you would like to do
   System.out.println("Welcome to the home screen of the game menu.\n" +
    "From here you will make your selection of what you \n" +
    "would like to do today. Here are your choices and how\n" +
    "to select them:\nTo play the RandomNumberGame:rng\n" +
    "View the current session scores:s\n" +
    "To clear the current session scores:es\n" +
    "To quit the game:kill\n" +
    "To play my bonus game:b\n" + // Extra credit #2
    "I hope you enjoy my program and have a nice day " + userName);
   System.out.println("you can make your selection now");
   // Clears the option then stores the users input in the option variable 
   option = "";
   option = sc.next();
   System.out.println(option);
   // Switch used to navigate the menu based off what is in option.
   switch (option) 
   {// switch start #1
    case "rng":
      // Used at the end to possobly repeat the game.
      ply = "";
     // Explains the game to the user.
     System.out.println("Nice to meet you " + userName + ".\n" +
      "Today we are going to play a game. " +
      "In this game you will be trying to guess a random number " +
      "between 1-100.\nI will only give you a few tries so " +
      "try to guess sooner rather then later.\nGood luck!");
     // Start of my do while loop that resets the game 
     do 
     { // do while loop start of do #2
      //  Used for score
      check = false;
      // Used to keep track of your guesses
      guessNumber = 0;
      // Gets my random number then moves it into the computerNumber varable.
      computerNumber = (byte)(rnd.nextFloat() * 100 + 1);

      // While loop that allows the game to play based on the variable values
      while (guessNumber != limit) 
      { // while loop start #1 
          // The guess counter for your turn
          guessNumber++;
          // Score keeper
       score++;
       // Used to hold the score 
       previous = guessNumber;
       // Used to see if you went over the amount of attempts
       attempts = guessNumber;
          System.out.println("Please enter your guess now.");
       // Gets the users number.
       userNumber = sc.nextByte();
       // Determine if the userNumber
       // is greater than the computerNumber
       if (userNumber > computerNumber) 
       { // if start #1
        System.out.println("Sorry " + userNumber + " is too high try guessing"
                                    + " lower.");
       } // if end #1
       // Determine if the userNumber
       // is less than the computerNumber.
       else if (userNumber < computerNumber) 
       { // else if start #1
        System.out.println("Sorry " + userNumber + " is too low try guessing"
                                    + " higher.");
       } // else if end #1

       // The only other logical possibility is equilibrium.
       else 
       { // else start #1
        System.out.println("Congratulations! You are correct! Good guess! "+
                 computerNumber + " is"+
                 " equal to " + userNumber + ".");
        // Used for score
        check = true;
        
        System.out.println("Number of attempts: " + guessNumber);
        // Gets you out of the loop by making the varabile  guessNumber = limit
        guessNumber = limit / 2 * 2;
       } // else end #1
       // Determines if you get an error for going over the limit
       if (attempts == limit) 
       { // if start #2
        System.out.println(limit + " attempts exceded please try again");
       } // if end #2             
      } // End of while loop #1
      // If the user has excedid all there guesses they dont get any points
      if (guessNumber == limit && check != true) 
      { // if start #3
       previous = 0;
       score = 0;
      } // if end #3
         
      System.out.println("Would you like to play again yes/no?");
      
      ply = sc.next();
     } // do while loop end of do #2
     // Checks to see if the user wants to play again.
     while (ply.contains("yes")); // do while loop end of while #2
     // Thanks the user for playing
     System.out.println("Thanks for playing my game " + userName 
                                                      + " have a great day.");
     // End of the RandomNumberGame
     break;

    case "b":
     // Used at the end to possobly repeat the game.
     ply = "";
     // Explains the game to the user.
     System.out.println("Welcome to the cup game " + userName + ".\n" +
      "In this game you will chose between one of three cups.\n" +
      "Each cup will have a value inside of them, The goal is " +
      "to find the largest or smallest value under the correct cup.\n" +
      "It is randomly chosen whether you will be looking for the " +
      "smallest or largest value.\n"+ 
      "This is still a game of chance.");
     do { // do while loop start of do #3
          //Previous score
         cCheck = 0;
         // Gets 3 random numbers and stores them in variables
      red = (byte)(rnd.nextFloat() * 100 + 1);
      blue = (byte)(rnd.nextFloat() * 100 + 1);
      yellow = (byte)(rnd.nextFloat() * 100 + 1);
      // Difficulty just gives the user hints or takes them away
      System.out.println("First choose your difficulty by typing easy/hard.\n"+
               "Easy: Gives you a small hint to eliminate a choice.\n"+
               "Hard: Gives no hint just a game of luck,"+
               " I wish you luck you will need it.");
      System.out.println("Please enter your choice now.");
      option = sc.next();
      // If the user types hard, hints are disabled 
      if (option.contains("hard")) 
      { // if start #4
       difficulty = false;
      } // if end #4
      // If the user types easy, hints are enabled
      else if (option.contains("easy")) 
      { // else if start #2
       difficulty = true;
      } // else if end #2
      // If anything else is entered default is enabled
      else
      { // else start #2
       difficulty = true;
      } // else end #2
      // If difficulty is true then you get hints
      if (difficulty == true) 
      { // if start #5
       // If red is greater than blue you get that hint   
       if (red > blue) 
       { // if start #6
        System.out.println("Red is greater than blue!");
       } // if end #6
       // If yellow is greater than blue you get that hint
       else if (yellow > blue) 
       { // else if start #3
        System.out.println("Yellow is greater than blue!");
       } // else if end #3
       // If any of the variables are equal to each other you get no hint
       // im not completly sure this works so im taking it out
       // i think this breaks my hint system somtimes, im not sure why.
      // else if (red == blue || blue == yellow) 
     //  { // else if start #4
       // System.out.println("The odds are in your favor you do not need a hint"
              //  + ".");
      // } // else if end #4
      } // if end #5
      // Randomly picks a boolean to decide if you find the smaller or larger
      decider = (rnd.nextBoolean());
      if (decider == true) 
      { // if start #7
       // Finds the max value out of the three variables
       minMax = Math.max(red, Math.max(yellow, blue));
       guessNumber = (byte) minMax;
       System.out.println("Who do you think has the highest value?");
      } // if end #7
      else 
      { // else start #4
       // finds the smallest value out of the three variables
       minMax = Math.min(red, Math.min(yellow, blue));
       guessNumber = (byte) minMax;
       System.out.println("Who do you think has the lowest value?");
      } // else end #4

      // Gets the users choice
      System.out.println("Please enter your choice of: blue, yellow, red.");
      option = sc.next();
       // If you type one of the three choices the game checks to see if it is
       // equal to the value in guessNumber that holds the minoMax value.
       // If it is equal the user is congratulated. this general process is
       // done for each of the three cups. I could not find a better way to
       // do this with the tools I was aware of. I will section out one of the
       // processes with a blank comment to make it easy to break down.
       //
      while (option.contains("blue")) 
      { // while loop start #2  
       if (guessNumber == blue) 
       { // if start #9
           cScore++;
           cCheck++;
        System.out.println("Congratulations!");
        // Used to give a proper response to the large and small game decider.
        if (decider == false) 
        { // if start #10
         System.out.println("Blue has the " + small);
         option = "";
        } // if end #10
        else
        { // else start #5
         System.out.println("Blue has the " + large);
         option = "";
        } // else end #5
       } // if end #9
       // if the user is not correct you get a message
       else 
       { // else start #6
           System.out.println("Sorry thats not correct");
           option = "";
       } // else end #6
      } // while loop end #2
      //
       while (option.contains("yellow")) 
      { // while loop start #3
       if (guessNumber == yellow) 
       { // if start #11
           cScore++;
           cCheck++;
        System.out.println("Congratulations!");
        
        if (decider == false) 
        { // if start #12
         System.out.println("Yellow has the " + small);
         option = "";
        } // if end #12
        else
        { // else start #7
         System.out.println("Yellow has the " + large);
         option = "";
        } // else end #7
       } // if end #11
       else 
       { // else start #8
           System.out.println("Sorry thats not correct");
           option = "";
       } // else end #8
      } // while loop start #3
      while (option.contains("red")) 
      { // while loop start #4
       if (guessNumber == red) 
       { // if start #13
           cScore++;
           cCheck++;
        System.out.println("Congratulations!");
        
        if (decider == false) 
        { // if start #14
         System.out.println("Red has the " + small);
         option = "";
        } // if end #14
        else
        { // else start #9
         System.out.println("Red has the " + large);
         option = "";
        } // else end #9
       } // if end #13
       else 
       { // else start #10
           System.out.println("Sorry thats not correct");
           option = "";
       } // else end #10
      } // while loop start #4
     
      // Asks the user if they would liek to play again
      System.out.println("Would you like to play again yes/no?");
      ply = sc.next();
     } // do while loop end of do #3
     while (ply.contains("yes"));
     System.out.println("Thanks for playing my game " + userName 
                                                      + " have a great day.");
     break;

    case "kill":
     // stops the program
     System.exit(0);
     break;

    case "s":
     // Random Numbers Game
     // shows the score to the user
     System.out.println("Random Number Game");
     System.out.println("Totaled score: " + score);
     System.out.println("Current round score:" + previous);
     // Cup Game
     System.out.println("\nCup Game");
     System.out.println("Cup Game totaled score: "+cScore);
     if(cCheck == 1)
     {
         System.out.println("You got a point this round!");
     }
     else
     {
         System.out.println("You did not score a point this round!");
     }
     cCheck = 0;
     
     break;
    case "es":
      // when you come into this case the score is erased
     score = 0;
     previous = 0;
     cCheck = 0;
     cScore = 0;
     System.out.println("Random Number Game");
     System.out.println("Random Number Game totaled score:" + score);
     System.out.println("Current round score:" + previous);
     System.out.println("\nCup Game");
     System.out.println("Cup Game totaled score: "+cScore);
     break;
   }// switch end #1
   System.out.println("Do you want to go to the menu screen yes/no?");
   menuChoice = sc.next();
  } // do while loop end of do #1
  while (menuChoice.contains("yes")); // do while loop end of while #1      
 } // Main method  end     
} // RandomNumberGame class end
// created by Francis M Doncheski 