/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doncheski;

import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BankApp
{

    // used to get input throughout app.
    static Scanner inp = new Scanner(System.in);
    // used to format output where needed
    static DecimalFormat df = new DecimalFormat("$###,###.00");
    // Needed for log in and out
    static boolean log = false;

    public static void main(String[] args)
    {
        // Used to hold input for password or pin checking. 
        String infop = "";
        // Used to hold input for the Id
        int userNumb = 0;
        // Variables used to hold the Ids of bob, marry and sally
        int user1;
        int user2;
        int user3;
        long start = 500000000;
        long end = start - 1;
        // Used for condition checking
        //boolean log = true;
        boolean id = true;

        // Creates users
        Account bob = new Account("Bob Bones", "1111", 100);
        Account marry = new Account("Marry Mack", "2222", 200);
        Account sally = new Account("Sally Star", "1111", 300);

        // Gets the Id of each user and puts it into a variable
        user1 = bob.getAccountId();
        user2 = marry.getAccountId();
        user3 = sally.getAccountId();
        // While the id is set to true the user can enter there Id number
        while (id == true)
        {
            // An online genorator was used to format text into a 
            //large text logo
            System.out.println(" __    __   ___ _        __  ___  ___ ___   ___      ______  ___       ____  ____  ____      ____  __ __    __ __  _  _____     ____   ____ ____  __  _ __ \n"
                    + "|  |__|  | /  _] |      /  ]/   \\|   |   | /  _]    |      |/   \\     |    \\|    |/    |    |    \\|  |  |  /  ]  |/ ]/ ___/    |    \\ /    |    \\|  |/ ]  |\n"
                    + "|  |  |  |/  [_| |     /  /|     | _   _ |/  [_     |      |     |    |  o  )|  ||   __|    |  o  )  |  | /  /|  ' /(   \\_     |  o  )  o  |  _  |  ' /|  |\n"
                    + "|  |  |  |    _] |___ /  / |  O  |  \\_/  |    _]    |_|  |_|  O  |    |     ||  ||  |  |    |     |  |  |/  / |    \\ \\__  |    |     |     |  |  |    \\|__|\n"
                    + "|  `  '  |   [_|     /   \\_|     |   |   |   [_       |  | |     |    |  O  ||  ||  |_ |    |  O  |  :  /   \\_|     \\/  \\ |    |  O  |  _  |  |  |     \\__ \n"
                    + " \\      /|     |     \\     |     |   |   |     |      |  | |     |    |     ||  ||     |    |     |     \\     |  .  |\\    |    |     |  |  |  |  |  .  |  |\n"
                    + "  \\_/\\_/ |_____|_____|\\____|\\___/|___|___|_____|      |__|  \\___/     |_____|____|___,_|    |_____|\\__,_|\\____|__|\\_| \\___|    |_____|__|__|__|__|__|\\_|__|\n"
                    + " ____  _       ___  ____  _____  ___        ___ ____  ______   ___ ____       __ __  ___  __ __ ____       ____   ____ ____  __  _      ____ ___           \n"
                    + "|    \\| |     /  _]/    |/ ___/ /  _]      /  _]    \\|      | /  _]    \\     |  |  |/   \\|  |  |    \\     |    \\ /    |    \\|  |/ ]    |    |   \\          \n"
                    + "|  o  ) |    /  [_|  o  (   \\_ /  [_      /  [_|  _  |      |/  [_|  D  )    |  |  |     |  |  |  D  )    |  o  )  o  |  _  |  ' /      |  ||    \\         \n"
                    + "|   _/| |___|    _]     |\\__  |    _]    |    _]  |  |_|  |_|    _]    /     |  ~  |  O  |  |  |    /     |     |     |  |  |    \\      |  ||  D  |        \n"
                    + "|  |  |     |   [_|  _  |/  \\ |   [_     |   [_|  |  | |  | |   [_|    \\     |___, |     |  :  |    \\     |  O  |  _  |  |  |     \\     |  ||     |__      \n"
                    + "|  |  |     |     |  |  |\\    |     |    |     |  |  | |  | |     |  .  \\    |     |     |     |  .  \\    |     |  |  |  |  |  .  |     |  ||     |  |     \n"
                    + "|__|  |_____|_____|__|__| \\___|_____|    |_____|__|__| |__| |_____|__|\\_|    |____/ \\___/ \\__,_|__|\\_|    |_____|__|__|__|__|__|\\_|    |____|_____|__|     \n"
                    + "                                                                                                                                                           ");
            // try catch used to catch user error if abcd.. ect is enterd
            try
            {
                // getting input
                userNumb = inp.nextInt();
                // checking input to the variables that contain the user Ids.
                if (userNumb == user1)
                {
                    id = false;
                     log = false;
                } else if (userNumb == user2)
                {
                    id = false;
                    log = false;
                } else if (userNumb == user3)
                {
                    id = false;
                    log = false;
                } else if (userNumb == -1)
                {
                    System.exit(0);
                    // if the Id is not found you get this error
                } else
                {
                    System.out.println("id not found try again.");
                    log = true;
                }
                // if the input is not numeric you get this error
            } catch (InputMismatchException e)
            {
                System.out.println("Improper data type please enter numeric values.");
                log = true;
            }
            // clears the scanner
            inp.nextLine();
            // checks this boolean to see if you can move into the
            //password validation
            while (log != true)
            {// While loop start

                System.out.println("Welcome to Big Bucks Bank Please enter your Pin.");
                infop = "";

                infop = inp.next();

                // Checks user input with passwords and Ids that are set when
                // accounts are made 
                if (infop.contains(bob.getPassword()) && userNumb == bob.getAccountId())
                {
                    System.out.println("welcome Bob, Big Bucks Bank hopes"
                            + " you are having a wonderful day.");
                    // takes you to a method for the menu
                    inAccount(bob);
                    log = getLog();
                    if (log == true)
                    {
                        id = true;
                    }
                } else if (infop.contains(marry.getPassword()) && userNumb == marry.getAccountId())
                {
                    System.out.println("welcome Marry, Big Bucks Bank hopes"
                            + " you are having a wonderful day.");
                    inAccount(marry);
                    log = getLog();
                    if (log == true)
                    {
                        id = true;
                    }
                } else if (infop.contains(sally.getPassword()) && userNumb == sally.getAccountId())
                {
                    System.out.println("welcome Sally, Big Bucks Bank hopes"
                            + " you are having a wonderful day.");
                    inAccount(sally);
                    log = getLog();
                    if (log == true)
                    {
                        id = true;
                    }
                } // if the information you have enterd up to this if statment 
                // is incorrect you will be told so and made to restart
                else
                {

                    System.out.println("Wrong pin, the information you entored is incorrect.");
                    log = true;
                    id = true;
                }

            }

        }// While loop end

    }

    public static void inAccount(Account currAccount)
    {// inAccount method start
        // This method allows the user to decide what they are doing to there
        // account
        // Used to get the account name for the current user
        String userName = currAccount.getName();
        // Holds input
        double value = 0;
        // Used to get the balance of the current user
        double balance = currAccount.getBalance();
        // Used for switch
        byte menu = 0;
        // Used for validation checking
        boolean check = false;
        // used to repeat the function of wd and dp if bad input
        boolean rep = false;

        do
        {
            value = 0;
            // Explains the menu to the use
            System.out.println("Welcome to the menu screen " + userName
                    + " here are your options."
                    + "\n1. withdrawl"
                    + "\n2. deposite"
                    + "\n3. check balance"
                    + "\n4. logout");

            try
            {
                // gets user input
                menu = inp.nextByte();

                // used to make selection
                switch (menu)
                {// Switch menu stat
                    // Case 1 and 2 are fairly similer so most of my comments will be
                    // in the first case but not all. 
                    // Case 1 is used to do a withdrawal
                    case 1:
                        // Greet the user and ask how much money they want to take out
                        System.out.println("Hello " + userName + " please enter the amount you would like"
                                + " to withdraw from your account.");
                        // loop used to repeat the task until value is set to 0
                        while (value == 0)
                        {
                            // Try catch for user input again just like last time
                            // you cant enter abcd... etc
                            try
                            {
                                // Get user input
                                value = inp.nextInt();
                                // This method is what dose the work for the transaction
                                // so please skip to that method then come back
                                wd(value, currAccount, balance, check);
                            } catch (InputMismatchException e)
                            {   // Welcome back if you understood that lets continue
                                // if any input up to the user trying to take money out
                                // is not correct like abcd.. etc you get this
                                System.out.println("Improper data type please enter numeric values.");
                                rep = false;
                            }
                            if (rep == true)
                            {
                                inp.nextLine();
                                rep = false;
                            }

                        }

                        break;

                    case 2:
                        // Not to much changes here agian very similar  to wd
                        System.out.println("Hello " + userName + ""
                                + "please enter the amount you would like"
                                + " to deposit from your account.");

                        while (value == 0)
                        {
                            try
                            {
                                value = inp.nextDouble();
                                dep(value, currAccount, balance, check);
                            } catch (InputMismatchException e)
                            {
                                System.out.println("Improper data type please"
                                        + " enter numeric values.");
                                rep = true;
                            }

                            if (rep == true)
                            {
                                inp.nextLine();
                                rep = false;
                            }
                        }

                        break;

                    case 3:
      // Tells the user there current balance
      System.out.println("Hello " + currAccount.getName() + " "
      + "your current balance is:" + df.format(currAccount.getBalance()) + ".");
                        break;

                    case 4:
                        // exits the loop
                        //logging out the user
                        System.out.println("Have a nice day!");
                        setLog(true);
                        check = true;
                        break;
                }// switch menu end
            }// If wrong data type
            catch (InputMismatchException e)
            {
                if (menu > 5)
                {
                    System.out.println("Wrong number must be between 1-4");
                } else
                {
                    System.out.println("Wrong data type please enter one of "
                            + "the menu options presented.");

                }
                inp.nextLine();
            }

        } while (check == false);

    } // inAccount method end
    // Takes in same variables as wd

    public static void dep(double value, Account currAccount, double balance, boolean check)
    {
        do
        {// start of do loop #2
            check = true;
            if (value > 0)
            {
                // Main diffrence here we are adding to the account
                System.out.println("Balance before " + df.format(balance) + ".");
                balance += value;
                currAccount.setBalance(balance);
                System.out.println("Balance after transaction " + df.format(balance) + ".");
                check = false;
            } else if (value == -1)
            {
                System.out.println("Transaction terminated have a nice day.");
                check = false;
            } else
            {
                System.out.println("Transaction terminated Please enter a numeric"
                        + " value greator than 0.");
                check = true;
                value = inp.nextDouble();

            }
        }// end of do loop #2
        while (check == true);
    }

    //wd or withdraw method takes in the users input, identifies the user,
    //gets there balance and takes in a boolean used for input checking
    public static void wd(double value, Account currAccount, double balance, boolean check)
    {// wd method start
        do
        {// start of do loop
            // Makes sure boolean is true
            check = true;
            // Proceeds if the balance is greater than the users input
            // and if boolean check is true and if the value enterd
            // is greator than 0
            if (balance > value && check == true && value > 0)
            {// tells the user there balance before and after
                // the transaction is complete
                System.out.println("Balance before " + df.format(balance) + ".");
                balance -= value;
                // gets the balance of the current user and sets it to the
                // amount of balance
                currAccount.setBalance(balance);
                System.out.println("Balance after transaction " + df.format(balance) + ".");
                check = false;
                // If you do not have enough money then you can be told so
                // and have another attempt to enter your withdraw
            } else if (value > balance)
            {
                System.out.println("Insufficient funds!");
                System.out.println("Current balance: " + df.format(balance) + ".");
                check = true;
                System.out.println("Please enter the amount you would like to"
                        + " withdraw from your account or terminate your "
                        + " withdrawal by entering (-1).");
                value = inp.nextDouble();
                // If you are finished and you do not
                // wish to complete a withdraw you may exit with -1
            } else if (value == -1)
            {// If you decide not to take out funds this message will display
                System.out.println("Transaction terminated have a nice day.");
                check = false;
            } else
            {// if the transaction terminats for any other reason such as
                // bad input you get htis statment
                System.out.println("Transaction terminated Please enter "
                        + "a numeric value greator than 0.");
                check = true;
                value = inp.nextDouble();
            }
        }// end of do loop 
        while (check == true);
    }// wd method end
    // This set and get allows you to log in and out depending on the
    // locaiton of the user.
    public static void setLog(boolean logs)
    {

        log = logs;
    }

    public static boolean getLog()
    {

        return log;
    }

}// BankApp class end